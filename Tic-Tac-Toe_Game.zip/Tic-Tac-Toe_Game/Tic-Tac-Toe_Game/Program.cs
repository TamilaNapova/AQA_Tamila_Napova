﻿using System;

namespace Tic_Tac_Toe_Game
{
    class TicTacToeGame
    {
        private char[,] board;
        private char currentPlayer;

        public TicTacToeGame()
        {
            board = new char[3, 3];
            currentPlayer = 'X';
            InitializeBoard();
        }

        private void InitializeBoard()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    board[i, j] = ' ';
                }
            }
        }

        public void StartGame()
        {
            Console.WriteLine("Добро пожаловать в игру Крестики-нолики!");
            Console.Write("Введите имя первого игрока (крестики): ");
            string playerX = Console.ReadLine();
            Console.Write("Введите имя второго игрока (нолики): ");
            string playerO = Console.ReadLine();

            do
            {
                DisplayBoard();
                MakeMove();

                if (CheckForWinner())
                {
                    DisplayBoard();
                    Console.WriteLine($"Игрок {currentPlayer} ({(currentPlayer == 'X' ? playerX : playerO)}) победил!");
                    break;
                }

                if (IsBoardFull())
                {
                    DisplayBoard();
                    Console.WriteLine("Игра закончилась вничью!");
                    break;
                }

                SwitchPlayer();
            } while (true);

            Console.WriteLine("Желаете начать новую игру? (y/n)");
            string playAgain = Console.ReadLine();
            if (playAgain.Equals("y", StringComparison.OrdinalIgnoreCase))
            {
                StartGame();
            }
            else
            {
                Console.WriteLine("Игра завершена. До свидания!");
            }
        }

        private void DisplayBoard()
        {
            Console.Clear();
            Console.WriteLine("Текущее состояние игрового поля:");
            Console.WriteLine("  0 1 2");
            for (int i = 0; i < 3; i++)
            {
                Console.Write($"{i} ");
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{board[i, j]} ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        private void MakeMove()
        {
            int row, col;
            do
            {
                Console.WriteLine($"Ход игрока {currentPlayer}");
                Console.Write("Введите номер строки (0, 1, 2): ");
                row = GetValidInput();
                Console.Write("Введите номер столбца (0, 1, 2): ");
                col = GetValidInput();
            } while (board[row, col] != ' ');

            board[row, col] = currentPlayer;
        }

        private int GetValidInput()
        {
            int input;
            while (!int.TryParse(Console.ReadLine(), out input) || input < 0 || input > 2)
            {
                Console.WriteLine("Ошибка ввода. Введите корректное значение (0, 1, 2).");
            }
            return input;
        }

        private void SwitchPlayer()
        {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        private bool CheckForWinner()
        {
            // Проверка по горизонтали, вертикали и диагоналям
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] == currentPlayer && board[i, 1] == currentPlayer && board[i, 2] == currentPlayer)
                    return true;

                if (board[0, i] == currentPlayer && board[1, i] == currentPlayer && board[2, i] == currentPlayer)
                    return true;
            }

            if (board[0, 0] == currentPlayer && board[1, 1] == currentPlayer && board[2, 2] == currentPlayer)
                return true;

            if (board[0, 2] == currentPlayer && board[1, 1] == currentPlayer && board[2, 0] == currentPlayer)
                return true;

            return false;
        }

        private bool IsBoardFull()
        {
            foreach (var cell in board)
            {
                if (cell == ' ')
                    return false;
            }
            return true;
        }
    }

    class Program
    {
        static void Main()
        {
            TicTacToeGame game = new TicTacToeGame();
            game.StartGame();
        }
    }

}




