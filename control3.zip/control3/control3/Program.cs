﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace control3
{

    class Program
    {
        class Library
        {
            private string name = "Название библиотеки";
            private string address = "Адрес библиотеки";
            private string phoneNumber = "Номер телефона";
            private string librarianName = "Имя и фамилия библиотекаря";
            private List<Book> catalog = new List<Book>();
            private List<Transaction> transactions = new List<Transaction>();

            public Library()
            {
                // Инициализация библиотеки, каталога и т.д.
                catalog.Add(new Book { Title = "Книга 1", Author = "Автор 1", IsAvailable = true });
                catalog.Add(new Book { Title = "Книга 2", Author = "Автор 2", IsAvailable = true });
                // Добавьте остальные книги по аналогии
            }

            public void DisplayLibraryInformation()
            {
                Console.WriteLine($"Название библиотеки: {name}");
                Console.WriteLine($"Адрес: {address}");
                Console.WriteLine($"Номер телефона: {phoneNumber}");
                Console.WriteLine($"Библиотекарь: {librarianName}");
                Console.WriteLine();
            }

            public void DisplayCatalog()
            {
                Console.WriteLine("Каталог книг:");
                foreach (var book in catalog)
                {
                    Console.WriteLine($"Название: {book.Title}, Автор: {book.Author}, Доступна: {(book.IsAvailable ? "Да" : "Нет")}");
                }
                Console.WriteLine();
            }

            public void SearchBooks()
            {
                Console.WriteLine("Введите часть названия или автора книги для поиска:");
                string keyword = Console.ReadLine().ToLower();

                var searchResults = catalog
                    .Where(book => book.Title.ToLower().Contains(keyword) || book.Author.ToLower().Contains(keyword))
                    .ToList();

                Console.WriteLine("Результаты поиска:");
                foreach (var book in searchResults)
                {
                    Console.WriteLine($"Название: {book.Title}, Автор: {book.Author}");
                }
                Console.WriteLine();
            }

            public void HandleBookTransactions()
            {
                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1. Выдача книги");
                Console.WriteLine("2. Возврат книги");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        IssueBook();
                        break;
                    case 2:
                        ReturnBook();
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Пожалуйста, выберите снова.");
                        break;
                }
            }

            private void IssueBook()
            {
                Console.WriteLine("Введите номер книги для выдачи:");
                int bookIndex = int.Parse(Console.ReadLine()) - 1;

                if (bookIndex >= 0 && bookIndex < catalog.Count && catalog[bookIndex].IsAvailable)
                {
                    Console.WriteLine("Введите имя клиента:");
                    string customerName = Console.ReadLine();
                    Console.WriteLine("Введите номер телефона клиента:");
                    string customerPhoneNumber = Console.ReadLine();

                    Transaction transaction = new Transaction
                    {
                        CustomerName = customerName,
                        CustomerPhoneNumber = customerPhoneNumber,
                        IssueDate = DateTime.Now,
                        Book = catalog[bookIndex]
                    };

                    transactions.Add(transaction);
                    catalog[bookIndex].IsAvailable = false;

                    Console.WriteLine("Книга успешно выдана.");
                }
                else
                {
                    Console.WriteLine("Книга недоступна или введен некорректный номер книги.");
                }
            }

            private void ReturnBook()
            {
                Console.WriteLine("Введите номер книги для возврата:");
                int bookIndex = int.Parse(Console.ReadLine()) - 1;

                if (bookIndex >= 0 && bookIndex < catalog.Count && !catalog[bookIndex].IsAvailable)
                {
                    Console.WriteLine("Введите дату возврата (гггг-мм-дд):");
                    DateTime returnDate = DateTime.Parse(Console.ReadLine());

                    transactions
                        .Where(t => t.Book == catalog[bookIndex] && t.ReturnDate == null)
                        .ToList()
                        .ForEach(t => t.ReturnDate = returnDate);

                    catalog[bookIndex].IsAvailable = true;

                    Console.WriteLine("Книга успешно возвращена.");
                }
                else
                {
                    Console.WriteLine("Книга уже доступна или введен некорректный номер книги.");
                }
            }

            public void DisplayStatistics()
            {
                Console.WriteLine("1. Список клиентов, которые не вернули книги:");
                transactions
                    .Where(t => t.ReturnDate == null)
                    .GroupBy(t => t.CustomerName)
                    .ToList()
                    .ForEach(group =>
                    {
                        var transaction = group.First();
                        Console.WriteLine($"Клиент: {transaction.CustomerName}, Телефон: {transaction.CustomerPhoneNumber}");
                        Console.WriteLine($"Дата выдачи: {transaction.IssueDate}, Книга: {transaction.Book.Title}, Автор: {transaction.Book.Author}");
                    });

                Console.WriteLine("2. Статистика по книгам:");
                transactions
                    .GroupBy(t => t.Book)
                    .ToList()
                    .ForEach(group =>
                    {
                        var transaction = group.First();
                        Console.WriteLine($"Книга: {transaction.Book.Title}, Автор: {transaction.Book.Author}");
                        group.ToList().ForEach(t =>
                        {
                            Console.WriteLine($"Дата выдачи: {t.IssueDate}, Дата возврата: {t.ReturnDate ?? DateTime.Now}");
                        });
                    });
            }

        }

        class Book
        {
            public string Title { get; set; }
            public string Author { get; set; }
            // Дополнительная информация о книге
            public bool IsAvailable { get; set; }
        }

        class Transaction
        {
            public string CustomerName { get; set; }
            public string CustomerPhoneNumber { get; set; }
            public DateTime IssueDate { get; set; }
            public DateTime? ReturnDate { get; set; }
            public Book Book { get; set; }
        }


        static void Main()
        {
            Library library = new Library();

            while (true)
            {
                Console.WriteLine("Главное меню:");
                Console.WriteLine("1. Контактная информация о библиотеке");
                Console.WriteLine("2. Каталог");
                Console.WriteLine("3. Поиск");
                Console.WriteLine("4. Выдача и возврат книг");
                Console.WriteLine("5. Статистика");
                Console.WriteLine("6. Завершение работы");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        library.DisplayLibraryInformation();
                        break;
                    case 2:
                        library.DisplayCatalog();
                        break;
                    case 3:
                        library.SearchBooks();
                        break;
                    case 4:
                        library.HandleBookTransactions();
                        break;
                    case 5:
                        library.DisplayStatistics();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Пожалуйста, выберите снова.");
                        break;
                }
            }
        }
    }

    class Library
    {
        private string name;
        private string address;
        private string phoneNumber;
        private string librarianName;
        private List<Book> catalog;
        private List<Transaction> transactions;

        public Library()
        {
            // Инициализация библиотеки, каталога и т.д.
        }

        public void DisplayLibraryInformation()
        {
            // Отображение информации о библиотеке
        }

        public void DisplayCatalog()
        {
            // Отображение каталога
        }

        public void SearchBooks()
        {
            // Поиск книг по автору или названию
        }

        public void HandleBookTransactions()
        {
            // Обработка выдачи и возврата книг
        }

        public void DisplayStatistics()
        {
            // Отображение статистики
        }
    }

    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        // Дополнительная информация о книге

        public bool IsAvailable { get; set; }
    }

    class Transaction
    {
        public string CustomerName { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public Book Book { get; set; }
    }


}

