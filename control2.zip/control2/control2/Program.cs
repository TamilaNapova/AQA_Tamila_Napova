﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace control2
{
    class PlayerRating
    {
        public string PlayerName { get; set; }
        public int Points { get; set; }

        public PlayerRating(string playerName, int points)
        {
            PlayerName = playerName;
            Points = points;
        }
    }

    class GameResult
    {
        public DateTime Date { get; set; }
        public string Player1 { get; set; }
        public string Player2 { get; set; }
        public int Player1Points { get; set; }
        public int Player2Points { get; set; }
        public string Winner { get; set; }

        public GameResult(DateTime date, string player1, string player2, int player1Points, int player2Points, string winner)
        {
            Date = date;
            Player1 = player1;
            Player2 = player2;
            Player1Points = player1Points;
            Player2Points = player2Points;
            Winner = winner;
        }
    }

    class Program
    {
        // Вынесение некоторых переменных в глобальные для удобства работы
        static List<PlayerRating> playerRatings = new List<PlayerRating>();
        static List<GameResult> gameResults = new List<GameResult>();

        static void Main()
        {
            while (true)
            {
                Console.WriteLine("Меню:");
                Console.WriteLine("a. 1 игрок (игра с ботом)");
                Console.WriteLine("b. 2 игрока (1 на 1)");
                Console.WriteLine("c. Рейтинг");
                Console.WriteLine("d. Таблица игр");
                Console.WriteLine("e. Выход");

                char choice = char.ToLower(Console.ReadKey().KeyChar);
                Console.WriteLine();

                switch (choice)
                {
                    case 'a':
                        PlayWithBot();
                        break;
                    case 'b':
                        Play1v1();
                        break;
                    case 'c':
                        ShowRating();
                        break;
                    case 'd':
                        ShowGameTable();
                        break;
                    case 'e':
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Пожалуйста, повторите.");
                        break;
                }
            }
        }

        static void PlayWithBot()
        {
            Console.Write("Введите ваше имя: ");
            string playerName = Console.ReadLine();

            Game game = new Game(playerName, "T1000");
            game.Start();

            SavePlayerRating(); // Сохранение рейтинга после окончания игры
        }

        static void Play1v1()
        {
            Console.Write("Введите имя первого игрока: ");
            string player1Name = Console.ReadLine();
            Console.Write("Введите имя второго игрока: ");
            string player2Name = Console.ReadLine();

            Game game = new Game(player1Name, player2Name);
            game.Start();

            SavePlayerRating(); // Сохранение рейтинга после окончания игры
        }

        static void ShowRating()
        {
            Console.WriteLine("Рейтинг игроков:");

            foreach (var playerRating in playerRatings.OrderByDescending(p => p.Points))
            {
                Console.WriteLine($"{playerRating.PlayerName} - {playerRating.Points} баллов");
            }
        }

        static void ShowGameTable()
        {
            Console.WriteLine("Таблица игр:");

            foreach (var gameResult in gameResults)
            {
                Console.WriteLine($"Дата: {gameResult.Date}, {gameResult.Player1} vs {gameResult.Player2}, Результат: {gameResult.Winner}");
            }
        }

        static void SavePlayerRating()
        {
            // Сохранение рейтинга в файл
            File.WriteAllLines("player_ratings.txt", playerRatings.Select(p => $"{p.PlayerName} {p.Points}"));
        }

        static void SaveGameResult(GameResult gameResult)
        {
            // Сохранение результатов игры в файл
            File.AppendAllText("game_results.txt", $"{gameResult.Date} - {gameResult.Player1}: {gameResult.Player1Points} баллов, {gameResult.Player2}: {gameResult.Player2Points} баллов{Environment.NewLine}");

            // Добавление результата в список для отображения таблицы игр
            gameResults.Add(gameResult);
        }

        class Game
        {
            private char[,] board;
            private string player1Name;
            private string player2Name;
            private int player1Score;
            private int player2Score;

            public Game(string player1, string player2)
            {
                player1Name = player1;
                player2Name = player2;
                board = new char[3, 3] { { ' ', ' ', ' ' }, { ' ', ' ', ' ' }, { ' ', ' ', ' ' } };
            }

            private bool MakeMoveFromInput(string playerName, char playerSymbol)
            {
                while (true)
                {
                    string input = Console.ReadLine();
                    string[] inputArray = input.Split(' ');

                    if (inputArray.Length != 2 || !int.TryParse(inputArray[0], out int row) || !int.TryParse(inputArray[1], out int col))
                    {
                        Console.WriteLine("Некорректный ввод. Пожалуйста, введите номер строки и столбца через пробел.");
                        continue;
                    }

                    if (MakeMove(row, col, playerSymbol))
                    {
                        return true;
                    }
                }
            }

            public void Start()
            {
                Console.WriteLine("Игра началась!");
                DisplayBoard();

                while (true)
                {
                    // Ход игрока 1
                    Console.WriteLine($"{player1Name}, ваш ход (введите номер строки и столбца через пробел): ");
                    if (MakeMoveFromInput(player1Name, 'X'))
                    {
                        DisplayBoard();
                        if (CheckWin('X'))
                        {
                            Console.WriteLine($"{player1Name} победил!");
                            SaveGameResult(new GameResult(DateTime.Now, player1Name, player2Name, player1Score, player2Score, player1Name));
                            break;
                        }
                        if (CheckDraw())
                        {
                            Console.WriteLine("Игра закончилась в ничью!");
                            SaveGameResult(new GameResult(DateTime.Now, player1Name, player2Name, player1Score, player2Score, "Ничья"));
                            break;
                        }
                    }

                    // Ход игрока 2
                    Console.WriteLine($"{player2Name}, ваш ход (введите номер строки и столбца через пробел): ");
                    if (MakeMoveFromInput(player2Name, 'O'))
                    {
                        DisplayBoard();
                        if (CheckWin('O'))
                        {
                            Console.WriteLine($"{player2Name} победил!");
                            SaveGameResult(new GameResult(DateTime.Now, player1Name, player2Name, player1Score, player2Score, player2Name));
                            break;
                        }
                        if (CheckDraw())
                        {
                            Console.WriteLine("Игра закончилась в ничью!");
                            SaveGameResult(new GameResult(DateTime.Now, player1Name, player2Name, player1Score, player2Score, "Ничья"));
                            break;
                        }
                    }
                }
            }

            private void DisplayBoard()
            {
                Console.WriteLine("Текущее состояние игрового поля:");

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        Console.Write($"{board[i, j]} ");
                    }
                    Console.WriteLine();
                }
            }

            private bool MakeMove(int row, int col, char playerSymbol)
            {
                if (row < 0 || row >= 3 || col < 0 || col >= 3 || board[row, col] != ' ')
                {
                    Console.WriteLine("Некорректный ход. Повторите попытку.");
                    return false;
                }

                board[row, col] = playerSymbol;

                // Увеличение баллов соответствующего игрока
                if (playerSymbol == 'X')
                {
                    player1Score++;
                }
                else if (playerSymbol == 'O')
                {
                    player2Score++;
                }

                return true;
            }

            private bool CheckWin(char playerSymbol)
            {
                // Проверка по горизонтали, вертикали и диагоналям
                for (int i = 0; i < 3; i++)
                {
                    if (board[i, 0] == playerSymbol && board[i, 1] == playerSymbol && board[i, 2] == playerSymbol)
                        return true;

                    if (board[0, i] == playerSymbol && board[1, i] == playerSymbol && board[2, i] == playerSymbol)
                        return true;
                }

                if (board[0, 0] == playerSymbol && board[1, 1] == playerSymbol && board[2, 2] == playerSymbol)
                    return true;

                if (board[0, 2] == playerSymbol && board[1, 1] == playerSymbol && board[2, 0] == playerSymbol)
                    return true;

                return false;
            }

            private bool CheckDraw()
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (board[i, j] == ' ')
                            return false;
                    }
                }
                return true;
            }

            private void SaveGameResult(GameResult gameResult)
            {
                // Сохранение результатов игры в файл
                File.AppendAllText("game_results.txt", $"{gameResult.Date} - {gameResult.Player1}: {gameResult.Player1Points} баллов, {gameResult.Player2}: {gameResult.Player2Points} баллов, {gameResult.Winner}{Environment.NewLine}");

                // Добавление результата в список для отображения таблицы игр
                gameResults.Add(gameResult);
            }
        }
    }
}
